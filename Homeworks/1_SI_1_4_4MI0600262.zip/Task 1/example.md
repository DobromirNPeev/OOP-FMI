|Segmen|Country|Product|Discount Band|
| :-----------------:| :-----------------:| ------------------:| :-----------------:|
|Government|Canada|Carretera|None|
|Government|Germany|Carretera|None|
|Midmarket|France|Carretera|None|
|Midmarket|Germany|Carretera|None|
|Midmarket|Mexico|Carretera|None|
|Government|Germany|Carretera|None|
|Midmarket|Germany|Montana|None|
|Channel Partners|Canada|Montana|None|
|Government|France|Montana|None|
|Channel Partners|Germany|Montana|None|
|Midmarket|Mexico|Montana|None|
|Enterprise|Canada|Montana|None|
|Small Business|Mexico|Montana|None|
|Government|Germany|Montana|None|
|Enterprise|Canada|Montana|None|
|Midmarket|USA|Montana|None|
|Government|Canada|Paseo|None|
|Midmarket|Mexico|Paseo|None|
|Channel Partners|Canada|Paseo|None|
|Government|Germany|Paseo|None|
