//https://github.com/Angeld55/Introduction_to_programming_FMI/blob/main/Sem.%2008/toString.cpp
#pragma once
char getCharFromDigit(int digit);

unsigned getNumberLength(unsigned int n);


void toString(unsigned int n, char* str);